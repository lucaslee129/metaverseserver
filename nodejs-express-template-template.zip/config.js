require('dotenv').config();

const config = {
  port: 5000,
  dbUrlMongoDB: "mongodb+srv://price:123456789LionKing@cluster0.epz612r.mongodb.net/hiring",
  API_KEY_JWT: "qazwsxedc",
  TOKEN_EXPIRES_IN: "32",
};

module.exports = config;
